<?php
/**
 * Plugin Name: Movie and Songs Manager
 * Description: Manage movies, song lists, and lyrics. Works with any theme.
 * Author: Komara Yuvakiran
 * Version: 1.3
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Register the Admin Menu
add_action('admin_menu', 'movie_songs_manager_menu');
function movie_songs_manager_menu()
{
    add_menu_page(
        'Movie Songs Manager',
        'Movie Songs Manager',
        'manage_options',
        'movie-songs-manager',
        'movie_songs_manager_page',
        'dashicons-format-audio',
        6
    );

    // Add submenu for creating the movie and song list page
    add_submenu_page(
        'movie-songs-manager',
        'Movie and Song List',
        'Movie & Song List',
        'manage_options',
        'movie-song-list',
        'movie_song_list_page'
    );
}

// Create Admin Page
function movie_songs_manager_page()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'movie_songs';

    // Create table if not exists
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id BIGINT(20) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        movie_name VARCHAR(255) NOT NULL,
        song_title VARCHAR(255) NOT NULL,
        youtube_url VARCHAR(255) NOT NULL,
        singer VARCHAR(255) NOT NULL,
        composer VARCHAR(255) NOT NULL,
        lyricist VARCHAR(255) NOT NULL,
        lyrics_telugu TEXT NOT NULL,
        lyrics_english TEXT NOT NULL,
        page_url VARCHAR(255) NOT NULL
    ) $charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Handle Form Submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['movie_name'])) {
        $movie_name = sanitize_text_field($_POST['movie_name']);
        $song_title = sanitize_text_field($_POST['song_title']);
        $youtube_url = esc_url_raw($_POST['youtube_url']);
        $singer = sanitize_text_field($_POST['singer']);
        $composer = sanitize_text_field($_POST['composer']);
        $lyricist = sanitize_text_field($_POST['lyricist']);
        $lyrics_telugu = sanitize_textarea_field($_POST['lyrics_telugu']);
        $lyrics_english = sanitize_textarea_field($_POST['lyrics_english']);

        // Extract YouTube video ID from the URL
        preg_match('/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/', $youtube_url, $matches);
        $video_id = isset($matches[1]) ? $matches[1] : '';

        // Generate YouTube embed URL
        $embed_url = $video_id ? "https://www.youtube.com/embed/{$video_id}" : '';

        // Generate YouTube Image URL
        $youtube_image_url = "https://img.youtube.com/vi/" . $video_id . "/0.jpg"; // Extract image from YouTube URL
        $page_content = "<div style='text-align:center; padding-bottom: 20px;'>";
        $page_content .= "<h1 style='font-size: 2em; color: #333;'>{$movie_name} - {$song_title}</h1>";
        $page_content .= "<img src='{$youtube_image_url}' alt='Song Image' style='max-width: 100%; height: auto; border-radius: 10px;' />";
        $page_content .= "</div>";

        // Song Details Section with Border and Grid Layout
        $page_content .= "<div style='display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; text-align: center; padding: 20px;'>";
        $page_content .= "<div style='background: #f9f9f9; border-radius: 8px; padding: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);'><h3>🎤 Singer</h3><p>{$singer}</p></div>";
        $page_content .= "<div style='background: #f9f9f9; border-radius: 8px; padding: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);'><h3>🎼 Composer</h3><p>{$composer}</p></div>";
        $page_content .= "<div style='background: #f9f9f9; border-radius: 8px; padding: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);'><h3>✍️ Lyricist</h3><p>{$lyricist}</p></div>";
        $page_content .= "</div>";

        // Lyrics Section
        $page_content .= "<div style='padding: 20px; background-color: #f9f9f9; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); margin-bottom: 20px;'><h2>📝 Lyrics in Telugu</h2><pre>{$lyrics_telugu}</pre></div>";
        $page_content .= "<div style='padding: 20px; background-color: #f9f9f9; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);'><h2>📝 Lyrics in English</h2><pre>{$lyrics_english}</pre></div>";

        // YouTube Video Embed
        $page_content .= "<div style='padding: 20px; text-align: center;'>";
        if ($embed_url) {
            $page_content .= "<iframe src='{$embed_url}' frameborder='0' allowfullscreen style='width: 100%; height: 400px; border-radius: 10px;'></iframe>";
        }
        $page_content .= "</div>";

        // Create WordPress Post (not page)
        $post_id = wp_insert_post([
            'post_title' => $movie_name . ' - ' . $song_title,
            'post_content' => $page_content,
            'post_status' => 'publish',
            'post_type' => 'post',
            'post_category' => [1], // Default category
            'meta_input' => [
                '_yoast_wpseo_title' => $movie_name . ' - ' . $song_title,
                '_yoast_wpseo_metadesc' => 'Watch ' . $song_title . ' from ' . $movie_name . ' on YouTube.',
            ]
        ]);

        $page_url = get_permalink($post_id);

        // Save Data to Database
        $wpdb->insert($table_name, [
            'movie_name' => $movie_name,
            'song_title' => $song_title,
            'youtube_url' => $youtube_url,
            'singer' => $singer,
            'composer' => $composer,
            'lyricist' => $lyricist,
            'lyrics_telugu' => $lyrics_telugu,
            'lyrics_english' => $lyrics_english,
            'page_url' => $page_url,
        ]);

        echo '<div class="updated"><p>Song added successfully! <a href="' . esc_url($page_url) . '">View Post</a></p></div>';
    }
    ?>
    <div class="wrap">
        <h1 style="margin-bottom: 20px; font-size: 2.5em; color: #333;">🎵 Movie Songs Manager</h1>
        <form method="POST" action="" style="background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
            <table class="form-table" style="width: 100%; max-width: 800px; margin: 0 auto;">
                <tr>
                    <th><label for="movie_name">🎥 Movie Name</label></th>
                    <td><input type="text" name="movie_name" id="movie_name" class="regular-text" required style="padding: 10px; border-radius: 5px; width: 100%;"></td>
                </tr>
                <tr>
                    <th><label for="song_title">🎶 Song Title</label></th>
                    <td><input type="text" name="song_title" id="song_title" class="regular-text" required style="padding: 10px; border-radius: 5px; width: 100%;"></td>
                </tr>
                <tr>
                    <th><label for="youtube_url">📹 YouTube URL</label></th>
                    <td><input type="url" name="youtube_url" id="youtube_url" class="regular-text" required style="padding: 10px; border-radius: 5px; width: 100%;"></td>
                </tr>
                <tr>
                    <th><label for="singer">🎤 Singer</label></th>
                    <td><input type="text" name="singer" id="singer" class="regular-text" required style="padding: 10px; border-radius: 5px; width: 100%;"></td>
                </tr>
                <tr>
                    <th><label for="composer">🎼 Composer</label></th>
                    <td><input type="text" name="composer" id="composer" class="regular-text" required style="padding: 10px; border-radius: 5px; width: 100%;"></td>
                </tr>
                <tr>
                    <th><label for="lyricist">✍️ Lyricist</label></th>
                    <td><input type="text" name="lyricist" id="lyricist" class="regular-text" required style="padding: 10px; border-radius: 5px; width: 100%;"></td>
                </tr>
                <tr>
                    <th><label for="lyrics_telugu">📝 Lyrics in Telugu</label></th>
                    <td><textarea name="lyrics_telugu" id="lyrics_telugu" rows="5" class="large-text" required style="padding: 10px; border-radius: 5px; width: 100%;"></textarea></td>
                </tr>
                <tr>
                    <th><label for="lyrics_english">📝 Lyrics in English</label></th>
                    <td><textarea name="lyrics_english" id="lyrics_english" rows="5" class="large-text" required style="padding: 10px; border-radius: 5px; width: 100%;"></textarea></td>
                </tr>
            </table>
            <p class="submit" style="text-align: center;">
                <input type="submit" class="button-primary" value="Add Song" style="padding: 12px 24px; background-color: #0073aa; color: white; border-radius: 5px;">
            </p>
        </form>
    </div>
    <?php
}

// Movie Song List Page
function movie_song_list_page()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'movie_songs';

    // Fetch all songs
    $results = $wpdb->get_results("SELECT * FROM $table_name");

    if ($results) {
        echo '<div class="wrap">';
        echo '<h2>🎶 Movie & Song List</h2>';
        echo '<ul>';
        foreach ($results as $song) {
            echo '<li><a href="' . esc_url($song->page_url) . '">' . esc_html($song->movie_name) . ' - ' . esc_html($song->song_title) . '</a></li>';
        }
        echo '</ul>';
        echo '</div>';
    } else {
        echo '<div class="wrap"><p>No songs found.</p></div>';
    }
}